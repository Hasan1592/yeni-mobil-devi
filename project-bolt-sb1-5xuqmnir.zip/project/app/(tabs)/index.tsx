import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Calendar, Clock, MapPin, Plus, Search, Filter, CreditCard as Edit3, Trash2, Check, X, Users, BookOpen, Coffee, Zap, Palette } from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: 'academic' | 'social' | 'sports' | 'culture';
  isAttending: boolean;
  attendees: number;
}

const categoryIcons = {
  academic: BookOpen,
  social: Users,
  sports: Zap,
  culture: Palette,
};

const categoryColors = {
  academic: '#3B82F6',
  social: '#10B981',
  sports: '#F59E0B',
  culture: '#8B5CF6',
};

const categoryLabels = {
  academic: 'Akademik',
  social: 'Sosyal',
  sports: 'Spor',
  culture: 'Kültür',
};

export default function EventsScreen() {
  const [events, setEvents] = useState<Event[]>([
    {
      id: '1',
      title: 'React Native Workshop',
      description: 'Mobil uygulama geliştirme atölyesi. React Native ile modern uygulamalar geliştirmeyi öğrenin.',
      date: '2025-01-20',
      time: '14:00',
      location: 'Bilgisayar Mühendisliği Amfisi',
      category: 'academic',
      isAttending: true,
      attendees: 45,
    },
    {
      id: '2',
      title: 'Kampüs Kahve Buluşması',
      description: 'Öğrenciler arası networking etkinliği. Yeni arkadaşlar edinmek için harika bir fırsat.',
      date: '2025-01-18',
      time: '16:30',
      location: 'Kafeterya Bahçesi',
      category: 'social',
      isAttending: false,
      attendees: 28,
    },
    {
      id: '3',
      title: 'Basketbol Turnuvası',
      description: 'Fakülteler arası basketbol turnuvası başlıyor. Takımınızı desteklemeyi unutmayın!',
      date: '2025-01-22',
      time: '18:00',
      location: 'Spor Salonu',
      category: 'sports',
      isAttending: true,
      attendees: 120,
    },
    {
      id: '4',
      title: 'Sanat Sergisi Açılışı',
      description: 'Güzel Sanatlar öğrencilerinin yıl sonu sergisi. Muhteşem eserleri görme fırsatı.',
      date: '2025-01-25',
      time: '19:00',
      location: 'Sanat Galerisi',
      category: 'culture',
      isAttending: false,
      attendees: 67,
    },
  ]);

  const [modalVisible, setModalVisible] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filterModalVisible, setFilterModalVisible] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    category: 'academic' as Event['category'],
  });

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      date: '',
      time: '',
      location: '',
      category: 'academic',
    });
  };

  const openModal = (event?: Event) => {
    if (event) {
      setEditingEvent(event);
      setFormData({
        title: event.title,
        description: event.description,
        date: event.date,
        time: event.time,
        location: event.location,
        category: event.category,
      });
    } else {
      setEditingEvent(null);
      resetForm();
    }
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingEvent(null);
    resetForm();
  };

  const saveEvent = () => {
    if (!formData.title || !formData.date || !formData.time) {
      Alert.alert('Hata', 'Lütfen zorunlu alanları doldurun.');
      return;
    }

    const eventData = {
      ...formData,
      attendees: editingEvent?.attendees || 0,
      isAttending: editingEvent?.isAttending || false,
    };

    if (editingEvent) {
      setEvents(events.map(event => 
        event.id === editingEvent.id 
          ? { ...eventData, id: editingEvent.id }
          : event
      ));
    } else {
      const newEvent = {
        ...eventData,
        id: Date.now().toString(),
      };
      setEvents([newEvent, ...events]);
    }

    closeModal();
  };

  const deleteEvent = (eventId: string) => {
    Alert.alert(
      'Etkinliği Sil',
      'Bu etkinliği silmek istediğinizden emin misiniz?',
      [
        { text: 'İptal', style: 'cancel' },
        {
          text: 'Sil',
          style: 'destructive',
          onPress: () => setEvents(events.filter(event => event.id !== eventId)),
        },
      ]
    );
  };

  const toggleAttendance = (eventId: string) => {
    setEvents(events.map(event => 
      event.id === eventId 
        ? { 
            ...event, 
            isAttending: !event.isAttending,
            attendees: event.isAttending ? event.attendees - 1 : event.attendees + 1
          }
        : event
    ));
  };

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || event.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const renderEventCard = (event: Event) => {
    const CategoryIcon = categoryIcons[event.category];
    const categoryColor = categoryColors[event.category];

    return (
      <View key={event.id} style={[styles.eventCard, { borderLeftColor: categoryColor }]}>
        <View style={styles.eventHeader}>
          <View style={styles.eventTitleRow}>
            <CategoryIcon size={20} color={categoryColor} />
            <Text style={styles.eventTitle}>{event.title}</Text>
          </View>
          <View style={styles.eventActions}>
            <TouchableOpacity onPress={() => openModal(event)} style={styles.actionButton}>
              <Edit3 size={16} color="#6B7280" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => deleteEvent(event.id)} style={styles.actionButton}>
              <Trash2 size={16} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.eventDescription}>{event.description}</Text>

        <View style={styles.eventDetails}>
          <View style={styles.eventDetailRow}>
            <Calendar size={16} color="#6B7280" />
            <Text style={styles.eventDetailText}>{formatDate(event.date)}</Text>
          </View>
          <View style={styles.eventDetailRow}>
            <Clock size={16} color="#6B7280" />
            <Text style={styles.eventDetailText}>{event.time}</Text>
          </View>
          <View style={styles.eventDetailRow}>
            <MapPin size={16} color="#6B7280" />
            <Text style={styles.eventDetailText}>{event.location}</Text>
          </View>
          <View style={styles.eventDetailRow}>
            <Users size={16} color="#6B7280" />
            <Text style={styles.eventDetailText}>{event.attendees} katılımcı</Text>
          </View>
        </View>

        <View style={styles.eventFooter}>
          <View style={[styles.categoryBadge, { backgroundColor: categoryColor + '20' }]}>
            <Text style={[styles.categoryBadgeText, { color: categoryColor }]}>
              {categoryLabels[event.category]}
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => toggleAttendance(event.id)}
            style={[
              styles.attendButton,
              { backgroundColor: event.isAttending ? '#10B981' : '#E5E7EB' }
            ]}
          >
            {event.isAttending ? (
              <Check size={16} color="#FFFFFF" />
            ) : (
              <Plus size={16} color="#6B7280" />
            )}
            <Text style={[
              styles.attendButtonText,
              { color: event.isAttending ? '#FFFFFF' : '#6B7280' }
            ]}>
              {event.isAttending ? 'Katılıyorum' : 'Katıl'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Kampüs Etkinlikleri</Text>
        <Text style={styles.headerSubtitle}>Üniversite etkinliklerini keşfet</Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Etkinlik ara..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity 
          style={styles.filterButton} 
          onPress={() => setFilterModalVisible(true)}
        >
          <Filter size={20} color="#6B7280" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.eventsList} showsVerticalScrollIndicator={false}>
        {filteredEvents.map(renderEventCard)}
        {filteredEvents.length === 0 && (
          <View style={styles.emptyState}>
            <Calendar size={48} color="#D1D5DB" />
            <Text style={styles.emptyStateText}>Etkinlik bulunamadı</Text>
            <Text style={styles.emptyStateSubtext}>
              Arama kriterlerinizi değiştirin veya yeni etkinlik ekleyin
            </Text>
          </View>
        )}
      </ScrollView>

      <TouchableOpacity style={styles.fab} onPress={() => openModal()}>
        <Plus size={24} color="#FFFFFF" />
      </TouchableOpacity>

      {/* Event Form Modal */}
      <Modal visible={modalVisible} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={closeModal}>
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              {editingEvent ? 'Etkinliği Düzenle' : 'Yeni Etkinlik'}
            </Text>
            <TouchableOpacity onPress={saveEvent}>
              <Text style={styles.saveButton}>Kaydet</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.formContainer}>
            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Başlık *</Text>
              <TextInput
                style={styles.formInput}
                value={formData.title}
                onChangeText={(text) => setFormData({ ...formData, title: text })}
                placeholder="Etkinlik başlığı"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Açıklama</Text>
              <TextInput
                style={[styles.formInput, styles.textArea]}
                value={formData.description}
                onChangeText={(text) => setFormData({ ...formData, description: text })}
                placeholder="Etkinlik açıklaması"
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Tarih *</Text>
              <TextInput
                style={styles.formInput}
                value={formData.date}
                onChangeText={(text) => setFormData({ ...formData, date: text })}
                placeholder="YYYY-MM-DD"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Saat *</Text>
              <TextInput
                style={styles.formInput}
                value={formData.time}
                onChangeText={(text) => setFormData({ ...formData, time: text })}
                placeholder="HH:MM"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Konum</Text>
              <TextInput
                style={styles.formInput}
                value={formData.location}
                onChangeText={(text) => setFormData({ ...formData, location: text })}
                placeholder="Etkinlik konumu"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Kategori</Text>
              <View style={styles.categorySelector}>
                {Object.entries(categoryLabels).map(([key, label]) => (
                  <TouchableOpacity
                    key={key}
                    style={[
                      styles.categoryOption,
                      formData.category === key && styles.categoryOptionSelected
                    ]}
                    onPress={() => setFormData({ ...formData, category: key as Event['category'] })}
                  >
                    <Text style={[
                      styles.categoryOptionText,
                      formData.category === key && styles.categoryOptionTextSelected
                    ]}>
                      {label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Filter Modal */}
      <Modal visible={filterModalVisible} animationType="slide" transparent>
        <View style={styles.filterModalOverlay}>
          <View style={styles.filterModalContent}>
            <Text style={styles.filterModalTitle}>Kategori Filtresi</Text>
            
            <TouchableOpacity
              style={[
                styles.filterOption,
                selectedCategory === 'all' && styles.filterOptionSelected
              ]}
              onPress={() => {
                setSelectedCategory('all');
                setFilterModalVisible(false);
              }}
            >
              <Text style={[
                styles.filterOptionText,
                selectedCategory === 'all' && styles.filterOptionTextSelected
              ]}>
                Tüm Kategoriler
              </Text>
            </TouchableOpacity>

            {Object.entries(categoryLabels).map(([key, label]) => (
              <TouchableOpacity
                key={key}
                style={[
                  styles.filterOption,
                  selectedCategory === key && styles.filterOptionSelected
                ]}
                onPress={() => {
                  setSelectedCategory(key);
                  setFilterModalVisible(false);
                }}
              >
                <Text style={[
                  styles.filterOptionText,
                  selectedCategory === key && styles.filterOptionTextSelected
                ]}>
                  {label}
                </Text>
              </TouchableOpacity>
            ))}

            <TouchableOpacity
              style={styles.filterCloseButton}
              onPress={() => setFilterModalVisible(false)}
            >
              <Text style={styles.filterCloseButtonText}>Kapat</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    gap: 12,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1F2937',
  },
  filterButton: {
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    padding: 12,
  },
  eventsList: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  eventCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  eventTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    flex: 1,
  },
  eventActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    padding: 4,
  },
  eventDescription: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  eventDetails: {
    gap: 8,
    marginBottom: 16,
  },
  eventDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  eventDetailText: {
    fontSize: 14,
    color: '#4B5563',
  },
  eventFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  categoryBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  attendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  attendButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    backgroundColor: '#3B82F6',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    paddingHorizontal: 32,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  saveButton: {
    fontSize: 16,
    fontWeight: '600',
    color: '#3B82F6',
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  formGroup: {
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  formInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#1F2937',
    backgroundColor: '#FFFFFF',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  categorySelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryOption: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  categoryOptionSelected: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  categoryOptionText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  categoryOptionTextSelected: {
    color: '#FFFFFF',
  },
  filterModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  filterModalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 40,
  },
  filterModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 20,
    textAlign: 'center',
  },
  filterOption: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 8,
    backgroundColor: '#F9FAFB',
  },
  filterOptionSelected: {
    backgroundColor: '#3B82F6',
  },
  filterOptionText: {
    fontSize: 16,
    color: '#374151',
    textAlign: 'center',
  },
  filterOptionTextSelected: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  filterCloseButton: {
    marginTop: 16,
    paddingVertical: 12,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
  },
  filterCloseButtonText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    fontWeight: '500',
  },
});